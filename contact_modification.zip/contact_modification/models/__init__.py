
from . import res_partner
from . import purchase
from . import res_partner_clx_child
